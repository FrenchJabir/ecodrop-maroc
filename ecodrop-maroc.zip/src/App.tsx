/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, FormEvent } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Package, Leaf, MapPin, Shield, Train, Bike, Car, 
  Menu, X, ChevronRight, Check, Star, MessageSquare, ArrowRight, Clock,
  Plus, Search, HelpCircle, Heart, Zap, Coffee, Send, ChevronDown, Award
} from "lucide-react";

// Types de données pour les trajets et colis
interface Trajet {
  id: string;
  conducteur: string;
  avatar: string;
  departs: string;
  arrivee: string;
  date: string;
  moyenTransport: "train" | "tram" | "voiture";
  tailleColis: string;
  tarif: number;
  rating: number;
  livraisonsCount: number;
  statut: string;
}

interface Colis {
  id: string;
  titre: string;
  depart: string;
  arrivee: string;
  date: string;
  taille: "Enveloppe" | "Moyen" | "Grand";
  tarifPropose: number;
  expediteur: string;
}

export default function App() {
  // Navigation active sur mobile
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // États pour le simulateur interactif
  const [distance, setDistance] = useState<number>(250); // par défaut Casa - Marrakech (250km)
  const [transportMode, setTransportMode] = useState<"train" | "tram" | "voiture">("train");
  const [isCalculating, setIsCalculating] = useState(false);
  const [showResults, setShowResults] = useState(true);
  const [calculationResults, setCalculationResults] = useState({
    co2Saved: 41.25,
    moneySaved: 135,
    teaGlasses: 16
  });

  // Ville de départ et arrivée par défaut pour les filtres de recherche
  const [searchDepart, setSearchDepart] = useState<string>("");
  const [searchArrivee, setSearchArrivee] = useState<string>("");
  const [activeTab, setActiveTab] = useState<"trajets" | "colis">("trajets");

  // Données de simulation pour les trajets actifs (Droppers)
  const [trajets, setTrajets] = useState<Trajet[]>([
    {
      id: "t-1",
      conducteur: "Yassine El Amrani",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150",
      departs: "Casablanca",
      arrivee: "Marrakech",
      date: "Aujourd'hui à 15h30",
      moyenTransport: "train",
      tailleColis: "Petit (clés, ordi, plis)",
      tarif: 40,
      rating: 4.9,
      livraisonsCount: 42,
      statut: "Prend l'Al Boraq / ONCF"
    },
    {
      id: "t-2",
      conducteur: "Fatima-Zahra Alaoui",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150",
      departs: "Rabat",
      arrivee: "Tanger",
      date: "Demain à 08h30",
      moyenTransport: "voiture",
      tailleColis: "Moyen (boîte à chaussures)",
      tarif: 55,
      rating: 5.0,
      livraisonsCount: 18,
      statut: "Covoiturage Autoroute"
    },
    {
      id: "t-3",
      conducteur: "Amine Belkhayat",
      avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150",
      departs: "Casablanca (Maârif)",
      arrivee: "Rabat (Hay Riad)",
      date: "Chaque jour de semaine",
      moyenTransport: "train",
      tailleColis: "Plis & Documents",
      tarif: 25,
      rating: 4.8,
      livraisonsCount: 89,
      statut: "Trajet quotidien ONCF Navette"
    },
    {
      id: "t-4",
      conducteur: "Soufiane Bennani",
      avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150",
      departs: "Marrakech",
      arrivee: "Agadir",
      date: "Samedi prochain",
      moyenTransport: "voiture",
      tailleColis: "Grand (valise ou carton)",
      tarif: 75,
      rating: 4.7,
      livraisonsCount: 12,
      statut: "Départ week-end"
    },
    {
      id: "t-5",
      conducteur: "Kenza Tazi",
      avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150",
      departs: "Rabat-Ville",
      arrivee: "Rabat-Agdal",
      date: "Aujourd'hui à 18h00",
      moyenTransport: "tram",
      tailleColis: "Petits plis uniquement",
      tarif: 15,
      rating: 4.9,
      livraisonsCount: 31,
      statut: "Tramway Ligne 1"
    }
  ]);

  // Données de simulation pour les colis en attente d'expédition
  const [colis, setColis] = useState<Colis[]>([
    {
      id: "c-1",
      titre: "Clés d'appartement oubliées",
      depart: "Casablanca",
      arrivee: "Rabat",
      date: "Dès que possible",
      taille: "Enveloppe",
      tarifPropose: 30,
      expediteur: "Kamal O."
    },
    {
      id: "c-2",
      titre: "Boîte de gâteaux Beldi pour maman",
      depart: "Salé",
      arrivee: "Tanger",
      date: "Ce week-end",
      taille: "Moyen",
      tarifPropose: 45,
      expediteur: "Nadia M."
    },
    {
      id: "c-3",
      titre: "Ordinateur portable professionnel",
      depart: "Marrakech",
      arrivee: "Casablanca",
      date: "Avant mardi",
      taille: "Moyen",
      tarifPropose: 60,
      expediteur: "Tariq S."
    }
  ]);

  // États pour les modaux
  const [isDropperModalOpen, setIsDropperModalOpen] = useState(false);
  const [isExpedierModalOpen, setIsExpedierModalOpen] = useState(false);
  const [isChatModalOpen, setIsChatModalOpen] = useState(false);
  const [selectedDriver, setSelectedDriver] = useState<Trajet | null>(null);

  // État pour le chat simulé
  const [chatMessages, setChatMessages] = useState<Array<{ sender: "user" | "driver"; text: string; time: string }>>([]);
  const [currentChatMessage, setCurrentChatMessage] = useState("");
  const [isDriverTyping, setIsDriverTyping] = useState(false);

  // Formulaires de soumission
  const [newTrajet, setNewTrajet] = useState({
    conducteur: "Moi (Futur Dropper)",
    departs: "",
    arrivee: "",
    date: "Aujourd'hui",
    moyenTransport: "train" as "train" | "tram" | "voiture",
    tailleColis: "Moyen (boîte à chaussures)",
    tarif: 30,
    statut: "Trajet personnalisé"
  });

  const [newColis, setNewColis] = useState({
    titre: "",
    depart: "",
    arrivee: "",
    date: "Dès que possible",
    taille: "Moyen" as "Enveloppe" | "Moyen" | "Grand",
    tarifPropose: 35,
    expediteur: "Moi (Expéditeur)"
  });

  // Notification d'actions réussies
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  // Recalculer l'impact écologique en temps réel ou au clic
  const calculateImpact = (dist: number, mode: "train" | "tram" | "voiture") => {
    setIsCalculating(true);
    
    // Émission moyenne d'un utilitaire de livraison dédié : 200g CO2 / km = 0.2 kg/km
    // Émissions alternatives :
    // - Train ONCF : ~15g (0.015 kg/km)
    // - Tram / Vélo : 0g (0 kg/km)
    // - Voiture partagée : Marginalement 0g car le trajet se fait de toute façon
    
    let alternativeEmissions = 0;
    if (mode === "train") alternativeEmissions = 0.015;
    else if (mode === "tram") alternativeEmissions = 0.00;
    else if (mode === "voiture") alternativeEmissions = 0.00; // covoiturage déjà prévu, empreinte marginale nulle pour le colis
    
    const co2Saved = Number((dist * (0.2 - alternativeEmissions)).toFixed(2));
    
    // Économie en DH comparé à un transporteur express traditionnel (qui facture cher)
    // Traditionnel : ~45 DH de base + 0.6 DH / km
    // EcoDrop : tarif libre suggéré ~15 DH de base + 0.15 DH / km
    const traditionalCost = 45 + 0.6 * dist;
    const ecoDropCost = 15 + 0.15 * dist;
    const moneySaved = Math.max(20, Math.round(traditionalCost - ecoDropCost));
    
    // Verres de thé de remerciement (à 8 DH le verre de thé à la menthe traditionnel)
    const teaGlasses = Math.max(1, Math.round(moneySaved / 8));

    setTimeout(() => {
      setCalculationResults({
        co2Saved,
        moneySaved,
        teaGlasses
      });
      setIsCalculating(false);
      setShowResults(true);
    }, 500);
  };

  // Déclencher le calcul quand la distance ou le transport change
  useEffect(() => {
    calculateImpact(distance, transportMode);
  }, [distance, transportMode]);

  // Gérer la soumission du formulaire de trajet
  const handleAddTrajet = (e: FormEvent) => {
    e.preventDefault();
    if (!newTrajet.departs || !newTrajet.arrivee) {
      alert("Veuillez remplir la ville de départ et d'arrivée.");
      return;
    }

    const created: Trajet = {
      id: `t-${Date.now()}`,
      conducteur: "Amine El Fassi (Vous)",
      avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150",
      departs: newTrajet.departs,
      arrivee: newTrajet.arrivee,
      date: newTrajet.date,
      moyenTransport: newTrajet.moyenTransport,
      tailleColis: newTrajet.tailleColis,
      tarif: Number(newTrajet.tarif),
      rating: 5.0,
      livraisonsCount: 0,
      statut: newTrajet.statut
    };

    setTrajets([created, ...trajets]);
    setIsDropperModalOpen(false);
    showToast(`🇲🇦 Votre trajet ${newTrajet.departs} ➔ ${newTrajet.arrivee} a bien été publié ! Vous êtes officiellement un Dropper.`);
    // Réinitialisation
    setNewTrajet({
      conducteur: "Moi (Futur Dropper)",
      departs: "",
      arrivee: "",
      date: "Aujourd'hui",
      moyenTransport: "train",
      tailleColis: "Moyen (boîte à chaussures)",
      tarif: 30,
      statut: "Trajet personnalisé"
    });
  };

  // Gérer la soumission du colis à expédier
  const handleAddColis = (e: FormEvent) => {
    e.preventDefault();
    if (!newColis.titre || !newColis.depart || !newColis.arrivee) {
      alert("Veuillez remplir les informations obligatoires.");
      return;
    }

    const created: Colis = {
      id: `c-${Date.now()}`,
      titre: newColis.titre,
      depart: newColis.depart,
      arrivee: newColis.arrivee,
      date: newColis.date,
      taille: newColis.taille,
      tarifPropose: Number(newColis.tarifPropose),
      expediteur: "Sara T."
    };

    setColis([created, ...colis]);
    setIsExpedierModalOpen(false);
    showToast(`📦 Votre colis "${newColis.titre}" a été publié avec succès. Les Droppers de la communauté vont vous contacter !`);
    // Réinitialisation
    setNewColis({
      titre: "",
      depart: "",
      arrivee: "",
      date: "Dès que possible",
      taille: "Moyen",
      tarifPropose: 35,
      expediteur: "Moi (Expéditeur)"
    });
  };

  // Lancer une discussion simulée avec un Dropper
  const startChat = (driver: Trajet) => {
    setSelectedDriver(driver);
    setIsChatModalOpen(true);
    setChatMessages([
      {
        sender: "driver",
        text: `Salam Alaykoum ! Je fais le trajet ${driver.departs} ➔ ${driver.arrivee} en ${driver.moyenTransport === 'train' ? 'train ONCF' : driver.moyenTransport === 'tram' ? 'tramway' : 'voiture'}. Quel type de colis souhaites-tu envoyer ? 📦`,
        time: "10:02"
      }
    ]);
  };

  // Envoyer un message dans le chat simulé
  const sendChatMessage = (e: FormEvent) => {
    e.preventDefault();
    if (!currentChatMessage.trim()) return;

    const userMsg = {
      sender: "user" as const,
      text: currentChatMessage,
      time: "10:03"
    };

    setChatMessages(prev => [...prev, userMsg]);
    setCurrentChatMessage("");
    setIsDriverTyping(true);

    // Simuler une réponse marocaine chaleureuse après 1.5s
    setTimeout(() => {
      setIsDriverTyping(false);
      let replyText = "Parfait ! C'est tout à fait dans mes cordes. On peut se donner rendez-vous devant la gare/autoroute pour la remise. Qu'en penses-tu ? Marhaban bikom ! 😊🍵";
      if (selectedDriver?.moyenTransport === 'train') {
        replyText = `Pas de soucis, c'est tout à fait possible ! Je prends le train et je t'attendrai devant la gare de ${selectedDriver.arrivee}. Donne-moi juste les détails et c'est réglé, avec plaisir ! 🇲🇦⚡`;
      }
      setChatMessages(prev => [...prev, {
        sender: "driver" as const,
        text: replyText,
        time: "10:04"
      }]);
    }, 1500);
  };

  // Filtrer les trajets
  const filteredTrajets = trajets.filter(t => {
    const matchDep = searchDepart === "" || t.departs.toLowerCase().includes(searchDepart.toLowerCase());
    const matchArr = searchArrivee === "" || t.arrivee.toLowerCase().includes(searchArrivee.toLowerCase());
    return matchDep && matchArr;
  });

  // Filtrer les colis
  const filteredColis = colis.filter(c => {
    const matchDep = searchDepart === "" || c.depart.toLowerCase().includes(searchDepart.toLowerCase());
    const matchArr = searchArrivee === "" || c.arrivee.toLowerCase().includes(searchArrivee.toLowerCase());
    return matchDep && matchArr;
  });

  return (
    <div className="min-h-screen bg-gray-50 text-charcoal font-sans selection:bg-safran/30 selection:text-sunset relative overflow-hidden">
      
      {/* Toast Notification */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div 
            initial={{ opacity: 0, y: -50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.9 }}
            className="fixed top-24 left-1/2 -translate-x-1/2 z-50 bg-charcoal text-white px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-3 border border-menthe/30 max-w-md"
            id="notification-toast"
          >
            <div className="bg-menthe/20 p-2 rounded-full text-menthe">
              <Check className="w-5 h-5" />
            </div>
            <p className="text-sm font-medium">{toastMessage}</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* NAVBAR */}
      <nav className="fixed top-0 left-0 w-full bg-white/95 backdrop-blur-md border-b border-gray-100 z-40 transition-all duration-300 shadow-sm" id="main-nav">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20 items-center">
            
            {/* Logo SVG Ultra Personnalisé */}
            <a href="#" className="flex items-center gap-3 group" id="brand-logo">
              <div className="relative w-12 h-12 flex items-center justify-center rounded-xl bg-orange-50 group-hover:scale-105 transition-transform duration-300">
                <svg viewBox="0 0 100 100" className="w-9 h-9" fill="none" xmlns="http://www.w3.org/2000/svg">
                  {/* Boîte de colis en fond découpé */}
                  <path d="M20 35 L50 20 L80 35 L50 50 Z" stroke="#FF5722" strokeWidth="6" strokeLinejoin="round" fill="#FF5722" fillOpacity="0.1"/>
                  <path d="M20 35 L20 65 L50 80 L50 50 Z" stroke="#FF5722" strokeWidth="6" strokeLinejoin="round" />
                  <path d="M80 35 L80 65 L50 80 L50 50 Z" stroke="#FF5722" strokeWidth="6" strokeLinejoin="round" />
                  
                  {/* Feuille de menthe verte et icône de géolocalisation fusionnée */}
                  <path d="M50 15 C30 35 30 55 50 75 C70 55 70 35 50 15 Z" fill="#00E676" fillOpacity="0.8" stroke="#FFFFFF" strokeWidth="3" />
                  {/* Petit point de localisation au centre */}
                  <circle cx="50" cy="42" r="5" fill="#FFFFFF" />
                </svg>
                {/* Petit drapeau marocain stylisé en badge */}
                <div className="absolute -top-1 -right-1 bg-red-600 text-white rounded-full text-[8px] w-5 h-5 flex items-center justify-center border border-white font-bold">
                  🇲🇦
                </div>
              </div>
              <div className="flex flex-col">
                <span className="text-xl font-extrabold font-display tracking-tight text-charcoal flex items-center gap-1 leading-none">
                  EcoDrop <span className="text-sunset">Maroc</span>
                </span>
                <span className="text-[10px] font-semibold text-menthe tracking-widest uppercase mt-1 leading-none">Colis collaboratif</span>
              </div>
            </a>

            {/* Liens de navigation bureau */}
            <div className="hidden md:flex items-center gap-8" id="desktop-links">
              <a href="#concept" className="text-gray-600 hover:text-sunset font-medium text-sm transition-colors">Le Concept</a>
              <a href="#advantages" className="text-gray-600 hover:text-sunset font-medium text-sm transition-colors">Notre Mission</a>
              <a href="#simulator" className="text-gray-600 hover:text-sunset font-medium text-sm transition-colors">Calculateur CO2</a>
              <a href="#marketplace" className="text-gray-600 hover:text-sunset font-medium text-sm transition-colors">Trajets dispo</a>
              <a href="#faq" className="text-gray-600 hover:text-sunset font-medium text-sm transition-colors">F.A.Q</a>
            </div>

            {/* Boutons Navbar bureau */}
            <div className="hidden md:flex items-center gap-4" id="nav-actions">
              <button 
                onClick={() => setIsDropperModalOpen(true)}
                className="bg-sunset text-white hover:bg-sunset/90 font-semibold text-sm px-5 py-3 rounded-xl transition-all duration-300 shadow-md shadow-sunset/20 hover:translate-y-[-2px] hover:shadow-lg active:translate-y-0"
              >
                Devenir Dropper 🇲🇦
              </button>
            </div>

            {/* Menu burger mobile */}
            <div className="md:hidden flex items-center">
              <button 
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="text-charcoal focus:outline-none p-2 rounded-lg bg-gray-100"
                id="burger-btn"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>

          </div>
        </div>

        {/* Menu mobile déroulant */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-white border-b border-gray-100 px-4 pt-2 pb-6 space-y-3 overflow-hidden"
              id="mobile-menu"
            >
              <a 
                href="#concept" 
                onClick={() => setMobileMenuOpen(false)}
                className="block px-3 py-2..5 rounded-xl text-gray-700 hover:bg-orange-50 hover:text-sunset font-medium transition-all"
              >
                Le Concept
              </a>
              <a 
                href="#advantages" 
                onClick={() => setMobileMenuOpen(false)}
                className="block px-3 py-2.5 rounded-xl text-gray-700 hover:bg-orange-50 hover:text-sunset font-medium transition-all"
              >
                Notre Mission
              </a>
              <a 
                href="#simulator" 
                onClick={() => setMobileMenuOpen(false)}
                className="block px-3 py-2.5 rounded-xl text-gray-700 hover:bg-orange-50 hover:text-sunset font-medium transition-all"
              >
                Calculateur CO2
              </a>
              <a 
                href="#marketplace" 
                onClick={() => setMobileMenuOpen(false)}
                className="block px-3 py-2.5 rounded-xl text-gray-700 hover:bg-orange-50 hover:text-sunset font-medium transition-all"
              >
                Trajets dispo
              </a>
              <a 
                href="#faq" 
                onClick={() => setMobileMenuOpen(false)}
                className="block px-3 py-2.5 rounded-xl text-gray-700 hover:bg-orange-50 hover:text-sunset font-medium transition-all"
              >
                F.A.Q
              </a>
              <div className="pt-4 border-t border-gray-100 flex flex-col gap-3">
                <button 
                  onClick={() => { setMobileMenuOpen(false); setIsDropperModalOpen(true); }}
                  className="w-full bg-sunset text-white text-center py-3.5 rounded-xl font-semibold text-sm shadow-md"
                >
                  Devenir Dropper 🇲🇦
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* HERO SECTION */}
      <section className="relative pt-32 pb-24 md:pt-40 md:pb-32 overflow-hidden gradient-bg" id="hero">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Texte Hero */}
            <div className="lg:col-span-7 flex flex-col items-start space-y-6 text-left">
              
              <div className="inline-flex items-center gap-2 bg-gradient-to-r from-orange-500/10 to-amber-500/10 text-sunset px-4 py-2 rounded-full text-xs font-bold border border-sunset/10 shadow-sm">
                <Leaf className="w-3.5 h-3.5 text-menthe fill-menthe animate-pulse" />
                <span>LE BLABLACAR DU COLIS AU MAROC</span>
                <span className="text-gray-300">|</span>
                <span>Fait avec 💚 pour notre planète</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold font-display leading-[1.1] text-charcoal tracking-tight" id="hero-title">
                Vos colis livrés partout au Maroc par vos voisins, <span className="text-transparent bg-clip-text bg-gradient-to-r from-sunset via-safran to-menthe">100% éco-responsable</span> 🇲🇦⚡
              </h1>
              
              <p className="text-base sm:text-lg text-gray-600 max-w-xl font-normal leading-relaxed">
                Utilisez les trajets déjà prévus de milliers de voyageurs (train ONCF, tramway ou voiture) pour transporter vos objets du quotidien d'une ville à l'autre ou en milieu urbain. Moins cher, ultra-rapide, et extrêmement vert !
              </p>

              <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto pt-2" id="hero-cta">
                <button 
                  onClick={() => setIsExpedierModalOpen(true)}
                  className="bg-sunset text-white hover:bg-sunset/95 font-bold px-8 py-4.5 rounded-2xl transition-all duration-300 flex items-center justify-center gap-2 shadow-lg shadow-sunset/30 hover:shadow-xl hover:-translate-y-0.5 active:translate-y-0"
                >
                  <Package className="w-5 h-5" />
                  Expédier un colis
                </button>
                <button 
                  onClick={() => setIsDropperModalOpen(true)}
                  className="bg-white hover:bg-gray-50 text-charcoal font-bold px-8 py-4.5 rounded-2xl border-2 border-gray-200 transition-all duration-300 flex items-center justify-center gap-2 hover:border-sunset/50"
                >
                  <Plus className="w-5 h-5 text-sunset" />
                  Proposer un trajet
                </button>
              </div>

              <div className="flex flex-wrap gap-x-8 gap-y-4 pt-6 border-t border-gray-100 w-full" id="hero-metrics">
                <div>
                  <p className="text-3xl font-extrabold text-charcoal font-display">1 240 kg</p>
                  <p className="text-xs text-gray-500 font-medium uppercase tracking-wider mt-1">CO2 Épargné ce mois</p>
                </div>
                <div>
                  <p className="text-3xl font-extrabold text-charcoal font-display">12 400 DH</p>
                  <p className="text-xs text-gray-500 font-medium uppercase tracking-wider mt-1">Économisés par la communauté</p>
                </div>
                <div>
                  <p className="text-3xl font-extrabold text-charcoal font-display">150 +</p>
                  <p className="text-xs text-gray-500 font-medium uppercase tracking-wider mt-1">Droppers actifs aujourd'hui</p>
                </div>
              </div>

            </div>

            {/* Visuel interactif à droite (Simulateur d'application de transport) */}
            <div className="lg:col-span-5 relative w-full flex justify-center lg:justify-end" id="hero-visual">
              
              {/* Éléments de fond décoratifs */}
              <div className="absolute -top-12 -left-12 w-64 h-64 bg-sunset/10 rounded-full blur-3xl -z-10 animate-pulse"></div>
              <div className="absolute -bottom-12 -right-12 w-64 h-64 bg-menthe/10 rounded-full blur-3xl -z-10"></div>

              {/* Conteneur Smartphone / App Showcase */}
              <div className="w-full max-w-[360px] bg-charcoal text-white rounded-[40px] p-6 shadow-2xl border-8 border-gray-800 relative overflow-hidden aspect-[9/18]">
                {/* Encoche téléphone */}
                <div className="absolute top-0 left-1/2 -translate-x-1/2 h-6 w-36 bg-gray-800 rounded-b-2xl z-20"></div>

                {/* En-tête de l'application */}
                <div className="flex justify-between items-center mt-3 mb-6 relative z-10">
                  <div className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-full bg-menthe animate-ping"></div>
                    <span className="text-xs font-semibold text-gray-300">Live Droppers Maroc</span>
                  </div>
                  <span className="text-[10px] bg-sunset/20 text-sunset px-2.5 py-1 rounded-full font-bold border border-sunset/20">
                    Casa-Marrakech
                  </span>
                </div>

                <p className="text-sm text-gray-400 font-medium mb-4">Mise en relation immédiate :</p>

                {/* Cartes de droppers animées en liste */}
                <div className="space-y-3 relative z-10">
                  
                  {/* Dropper 1 */}
                  <motion.div 
                    initial={{ x: 50, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.2 }}
                    className="bg-white/5 backdrop-blur-md rounded-2xl p-3.5 border border-white/10 hover:border-white/20 transition-all cursor-pointer"
                    onClick={() => startChat(trajets[0])}
                  >
                    <div className="flex justify-between items-start">
                      <div className="flex items-center gap-3">
                        <img 
                          src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150" 
                          alt="Yassine" 
                          className="w-10 h-10 rounded-full object-cover border-2 border-sunset"
                        />
                        <div>
                          <p className="text-xs font-bold text-white flex items-center gap-1">
                            Yassine E. 
                            <span className="flex items-center text-[9px] text-safran">
                              ★ 4.9
                            </span>
                          </p>
                          <p className="text-[10px] text-gray-400">Prend l'ONCF à 15:30</p>
                        </div>
                      </div>
                      <span className="text-xs font-bold text-menthe bg-menthe/10 px-2 py-0.5 rounded-lg">40 DH</span>
                    </div>
                    
                    <div className="mt-3 pt-3 border-t border-white/5 flex items-center justify-between text-[10px] text-gray-300">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-sunset" /> Casa ➔ Marrakech
                      </span>
                      <span className="text-sunset font-bold flex items-center gap-0.5 hover:underline">
                        Discuter <MessageSquare className="w-3 h-3 ml-0.5" />
                      </span>
                    </div>
                  </motion.div>

                  {/* Dropper 2 */}
                  <motion.div 
                    initial={{ x: 50, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: 0.4 }}
                    className="bg-white/5 backdrop-blur-md rounded-2xl p-3.5 border border-white/10 hover:border-white/20 transition-all cursor-pointer"
                    onClick={() => startChat(trajets[1])}
                  >
                    <div className="flex justify-between items-start">
                      <div className="flex items-center gap-3">
                        <img 
                          src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150" 
                          alt="Fatima" 
                          className="w-10 h-10 rounded-full object-cover border-2 border-menthe"
                        />
                        <div>
                          <p className="text-xs font-bold text-white flex items-center gap-1">
                            Fatima Z. 
                            <span className="flex items-center text-[9px] text-safran">
                              ★ 5.0
                            </span>
                          </p>
                          <p className="text-[10px] text-gray-400">Covoiturage - Demain</p>
                        </div>
                      </div>
                      <span className="text-xs font-bold text-menthe bg-menthe/10 px-2 py-0.5 rounded-lg">55 DH</span>
                    </div>
                    
                    <div className="mt-3 pt-3 border-t border-white/5 flex items-center justify-between text-[10px] text-gray-300">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-sunset" /> Rabat ➔ Tanger
                      </span>
                      <span className="text-sunset font-bold flex items-center gap-0.5 hover:underline">
                        Discuter <MessageSquare className="w-3 h-3 ml-0.5" />
                      </span>
                    </div>
                  </motion.div>

                </div>

                {/* Footer smartphone */}
                <div className="absolute bottom-6 left-6 right-6 flex justify-between items-center text-[10px] text-gray-500 border-t border-white/5 pt-4">
                  <span>940+ colis livrés</span>
                  <span className="text-menthe">99.2% de satisfaction</span>
                </div>

              </div>

            </div>

          </div>
        </div>
      </section>

      {/* SECTION EXPLICATION CONCEPT */}
      <section className="py-20 bg-white border-y border-gray-100" id="concept">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-xs font-bold uppercase tracking-widest text-sunset bg-sunset/10 px-4 py-1.5 rounded-full">
              Comment ça marche ?
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold font-display text-charcoal mt-4 tracking-tight">
              Un fonctionnement ultra-simple basé sur l'entraide marocaine
            </h2>
            <p className="text-gray-500 mt-3 text-base sm:text-lg">
              Pas de camions supplémentaires. Seulement des citoyens qui rentabilisent leurs déplacements quotidiens ou inter-villes.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            
            {/* Étape 1 */}
            <div className="relative p-8 rounded-3xl bg-gray-50 hover:bg-white transition-all duration-300 border border-gray-100 hover:shadow-xl group">
              <div className="absolute top-6 right-8 text-5xl font-black text-gray-200/50 group-hover:text-sunset/10 transition-colors">01</div>
              <div className="w-14 h-14 bg-orange-100 rounded-2xl flex items-center justify-center text-sunset mb-6 group-hover:scale-110 transition-transform">
                <Package className="w-7 h-7" />
              </div>
              <h3 className="text-xl font-bold text-charcoal mb-3">1. Vous postez votre besoin</h3>
              <p className="text-sm text-gray-500 leading-relaxed">
                Indiquez les villes de départ/arrivée, la taille du colis (clés, pli urgent, boîte, sac de voyage) et le tarif symbolique proposé pour le service.
              </p>
            </div>

            {/* Étape 2 */}
            <div className="relative p-8 rounded-3xl bg-gray-50 hover:bg-white transition-all duration-300 border border-gray-100 hover:shadow-xl group">
              <div className="absolute top-6 right-8 text-5xl font-black text-gray-200/50 group-hover:text-menthe/10 transition-colors">02</div>
              <div className="w-14 h-14 bg-emerald-100 rounded-2xl flex items-center justify-center text-menthe mb-6 group-hover:scale-110 transition-transform">
                <Search className="w-7 h-7" />
              </div>
              <h3 className="text-xl font-bold text-charcoal mb-3">2. Un "Dropper" vous contacte</h3>
              <p className="text-sm text-gray-500 leading-relaxed">
                Un voyageur qui effectue déjà le même trajet (en train Al Boraq/ONCF ou en voiture) accepte de prendre soin de votre colis et vous contacte via le chat.
              </p>
            </div>

            {/* Étape 3 */}
            <div className="relative p-8 rounded-3xl bg-gray-50 hover:bg-white transition-all duration-300 border border-gray-100 hover:shadow-xl group">
              <div className="absolute top-6 right-8 text-5xl font-black text-gray-200/50 group-hover:text-safran/10 transition-colors">03</div>
              <div className="w-14 h-14 bg-amber-100 rounded-2xl flex items-center justify-center text-safran mb-6 group-hover:scale-110 transition-transform">
                <Heart className="w-7 h-7 fill-safran" />
              </div>
              <h3 className="text-xl font-bold text-charcoal mb-3">3. Livraison & Récompense</h3>
              <p className="text-sm text-gray-500 leading-relaxed">
                Vous vous transmettez le colis. Le destinataire le reçoit en main propre à la gare ou au point de rendez-vous convenu. Vous économisez et préservez l'environnement !
              </p>
            </div>

          </div>

        </div>
      </section>

      {/* SECTION LES AVANTAGES */}
      <section className="py-20 bg-gray-50" id="advantages">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-xs font-bold uppercase tracking-widest text-menthe bg-menthe/10 px-4 py-1.5 rounded-full">
              Pourquoi nous faire confiance ?
            </span>
            <h2 className="text-3xl font-extrabold font-display text-charcoal mt-4 tracking-tight">
              Les 3 piliers de la révolution EcoDrop
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8" id="advantages-grid">
            
            {/* Avantage 1 */}
            <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100 flex flex-col items-center text-center hover:shadow-md transition-all">
              <div className="w-16 h-16 bg-amber-500/10 rounded-full flex items-center justify-center text-safran mb-6">
                <Coffee className="w-8 h-8 fill-safran/20 text-safran" />
              </div>
              <h3 className="text-xl font-bold text-charcoal mb-3 font-display">Arrondissez vos fins de mois</h3>
              <p className="text-sm text-gray-500 leading-relaxed max-w-xs">
                Rentabilisez vos trajets inter-villes ou vos allers-retours quotidiens. Prendre un colis de 200g dans votre sac vous rembourse votre ticket de train ou votre carburant.
              </p>
            </div>

            {/* Avantage 2 */}
            <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100 flex flex-col items-center text-center hover:shadow-md transition-all">
              <div className="w-16 h-16 bg-orange-500/10 rounded-full flex items-center justify-center text-sunset mb-6">
                <Zap className="w-8 h-8 fill-sunset/20 text-sunset" />
              </div>
              <h3 className="text-xl font-bold text-charcoal mb-3 font-display">Rapide & Économique</h3>
              <p className="text-sm text-gray-500 leading-relaxed max-w-xs">
                Expédiez des clés de rechange, un câble oublié ou des documents de bureau en moins de 3 heures à un tarif défiant toute concurrence, sans le stress des formalités lourdes.
              </p>
            </div>

            {/* Avantage 3 */}
            <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100 flex flex-col items-center text-center hover:shadow-md transition-all">
              <div className="w-16 h-16 bg-emerald-500/10 rounded-full flex items-center justify-center text-menthe mb-6">
                <Leaf className="w-8 h-8 fill-menthe/20 text-menthe" />
              </div>
              <h3 className="text-xl font-bold text-charcoal mb-3 font-display">Impact Éco-Maroc</h3>
              <p className="text-sm text-gray-500 leading-relaxed max-w-xs">
                Un colis transporté par un voyageur ONCF ou un covoitureur, c'est un utilitaire polluant de moins sur l'axe Casablanca - Rabat - Tanger. Nos villes marocaines respirent enfin !
              </p>
            </div>

          </div>

        </div>
      </section>

      {/* SECTION SIMULATEUR INTERACTIF */}
      <section className="py-20 bg-gradient-to-br from-charcoal to-gray-900 text-white relative overflow-hidden" id="simulator">
        
        {/* Cercles de fond luminescents */}
        <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-96 h-96 bg-sunset/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-10 right-10 w-80 h-80 bg-menthe/10 rounded-full blur-3xl"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Titre et Explications */}
            <div className="lg:col-span-5 text-left space-y-6">
              <span className="text-xs font-bold uppercase tracking-widest text-menthe bg-menthe/20 px-4 py-1.5 rounded-full border border-menthe/30">
                Outil d'Impact Vert
              </span>
              <h2 className="text-3xl sm:text-4xl font-extrabold font-display leading-tight">
                Simulez votre geste écologique 🇲🇦
              </h2>
              <p className="text-gray-300 text-sm sm:text-base leading-relaxed">
                Notre algorithme évalue l'empreinte carbone évitée par rapport à une livraison express par camion classique de messagerie. Réglez les kilomètres, sélectionnez votre moyen de transport, et voyez l'équivalent concret en économie locale et en cadeaux de bienvenue !
              </p>

              <div className="space-y-4 pt-4 border-t border-white/10 hidden lg:block">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-orange-500/10 flex items-center justify-center text-sunset">
                    <Check className="w-4 h-4" />
                  </div>
                  <span className="text-xs text-gray-300">Méthode de calcul certifiée ADEME & ONCF</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-orange-500/10 flex items-center justify-center text-sunset">
                    <Check className="w-4 h-4" />
                  </div>
                  <span className="text-xs text-gray-300">Valorisation de l'économie circulaire marocaine</span>
                </div>
              </div>
            </div>

            {/* Carte du Simulateur Interactif */}
            <div className="lg:col-span-7" id="simulator-container">
              <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-[32px] p-6 sm:p-10 shadow-2xl">
                
                <h3 className="text-xl font-bold mb-8 flex items-center gap-2">
                  <span className="bg-sunset text-white p-1.5 rounded-lg text-xs font-black">ECO</span>
                  Simulateur de Trajet EcoDrop
                </h3>

                <div className="space-y-8">
                  
                  {/* Distance (km) */}
                  <div className="space-y-3 text-left">
                    <div className="flex justify-between items-center">
                      <label className="text-sm font-semibold text-gray-300">Distance à parcourir :</label>
                      <span className="text-2xl font-black font-display text-safran">
                        {distance} km
                      </span>
                    </div>
                    
                    {/* Range Slider */}
                    <input 
                      type="range" 
                      min="10" 
                      max="600" 
                      value={distance}
                      onChange={(e) => setDistance(Number(e.target.value))}
                      className="w-full h-2 bg-white/20 rounded-lg appearance-none cursor-pointer accent-sunset"
                    />

                    {/* Presets rapides de trajets marocains */}
                    <div className="flex flex-wrap gap-2 pt-2">
                      <button 
                        onClick={() => setDistance(10)}
                        className={`text-[10px] px-3 py-1 rounded-full font-bold border transition-all ${distance === 10 ? 'bg-sunset border-sunset text-white' : 'bg-white/5 border-white/10 text-gray-300 hover:bg-white/10'}`}
                      >
                        Casa Urbain (10 km)
                      </button>
                      <button 
                        onClick={() => setDistance(60)}
                        className={`text-[10px] px-3 py-1 rounded-full font-bold border transition-all ${distance === 60 ? 'bg-sunset border-sunset text-white' : 'bg-white/5 border-white/10 text-gray-300 hover:bg-white/10'}`}
                      >
                        Casa ➔ Rabat (60 km)
                      </button>
                      <button 
                        onClick={() => setDistance(250)}
                        className={`text-[10px] px-3 py-1 rounded-full font-bold border transition-all ${distance === 250 ? 'bg-sunset border-sunset text-white' : 'bg-white/5 border-white/10 text-gray-300 hover:bg-white/10'}`}
                      >
                        Casa ➔ Marrakech (250 km)
                      </button>
                      <button 
                        onClick={() => setDistance(330)}
                        className={`text-[10px] px-3 py-1 rounded-full font-bold border transition-all ${distance === 330 ? 'bg-sunset border-sunset text-white' : 'bg-white/5 border-white/10 text-gray-300 hover:bg-white/10'}`}
                      >
                        Rabat ➔ Tanger (330 km)
                      </button>
                      <button 
                        onClick={() => setDistance(550)}
                        className={`text-[10px] px-3 py-1 rounded-full font-bold border transition-all ${distance === 550 ? 'bg-sunset border-sunset text-white' : 'bg-white/5 border-white/10 text-gray-300 hover:bg-white/10'}`}
                      >
                        Marrakech ➔ Agadir (550 km)
                      </button>
                    </div>
                  </div>

                  {/* Mode de transport */}
                  <div className="space-y-3 text-left">
                    <label className="text-sm font-semibold text-gray-300">Votre moyen de transport prévu :</label>
                    <div className="grid grid-cols-3 gap-3">
                      
                      {/* Train ONCF */}
                      <button
                        onClick={() => setTransportMode("train")}
                        className={`flex flex-col items-center gap-2 p-4 rounded-2xl border transition-all ${transportMode === 'train' ? 'bg-orange-500/20 border-sunset text-sunset font-bold' : 'bg-white/5 border-white/10 text-gray-300 hover:bg-white/10'}`}
                      >
                        <Train className="w-6 h-6" />
                        <span className="text-xs">Train ONCF</span>
                      </button>

                      {/* Tram / Vélo */}
                      <button
                        onClick={() => setTransportMode("tram")}
                        className={`flex flex-col items-center gap-2 p-4 rounded-2xl border transition-all ${transportMode === 'tram' ? 'bg-emerald-500/20 border-menthe text-menthe font-bold' : 'bg-white/5 border-white/10 text-gray-300 hover:bg-white/10'}`}
                      >
                        <Bike className="w-6 h-6" />
                        <span className="text-xs">Tram / Vélo</span>
                      </button>

                      {/* Voiture partagée */}
                      <button
                        onClick={() => setTransportMode("voiture")}
                        className={`flex flex-col items-center gap-2 p-4 rounded-2xl border transition-all ${transportMode === 'voiture' ? 'bg-amber-500/20 border-safran text-safran font-bold' : 'bg-white/5 border-white/10 text-gray-300 hover:bg-white/10'}`}
                      >
                        <Car className="w-6 h-6" />
                        <span className="text-xs">Covoiturage</span>
                      </button>

                    </div>
                  </div>

                  {/* Bouton vibrant de calcul */}
                  <button 
                    onClick={() => calculateImpact(distance, transportMode)}
                    disabled={isCalculating}
                    className="w-full bg-gradient-to-r from-sunset via-safran to-menthe text-charcoal font-black py-4 rounded-2xl shadow-xl hover:scale-[1.02] active:scale-[1] transition-transform flex items-center justify-center gap-2 text-base cursor-pointer"
                  >
                    {isCalculating ? (
                      <div className="w-5 h-5 border-2 border-charcoal border-t-transparent rounded-full animate-spin"></div>
                    ) : (
                      <>
                        <Zap className="w-5 h-5 text-charcoal fill-charcoal" />
                        CALCULER MON IMPACT ÉCOLOGIQUE
                      </>
                    )}
                  </button>

                  {/* Affichage des résultats */}
                  {showResults && (
                    <motion.div 
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-6 border-t border-white/10"
                      id="simulator-results"
                    >
                      {/* Résultat CO2 */}
                      <div className="bg-white/5 rounded-2xl p-4 border border-white/5 text-center flex flex-col justify-center items-center">
                        <div className="w-10 h-10 rounded-full bg-menthe/20 flex items-center justify-center text-menthe mb-2">
                          <Leaf className="w-5 h-5 fill-menthe/10" />
                        </div>
                        <p className="text-2xl font-black text-menthe font-display">
                          {calculationResults.co2Saved} kg
                        </p>
                        <p className="text-[10px] text-gray-400 font-medium uppercase mt-1">CO2 Évité</p>
                      </div>

                      {/* Résultat Économie en DH */}
                      <div className="bg-white/5 rounded-2xl p-4 border border-white/5 text-center flex flex-col justify-center items-center">
                        <div className="w-10 h-10 rounded-full bg-orange-500/20 flex items-center justify-center text-sunset mb-2">
                          <span className="font-extrabold text-sm text-sunset">DH</span>
                        </div>
                        <p className="text-2xl font-black text-sunset font-display">
                          {calculationResults.moneySaved} DH
                        </p>
                        <p className="text-[10px] text-gray-400 font-medium uppercase mt-1">Gain Estimé</p>
                      </div>

                      {/* Équivalence thé marocain */}
                      <div className="bg-white/5 rounded-2xl p-4 border border-white/5 text-center flex flex-col justify-center items-center relative overflow-hidden group">
                        <div className="w-10 h-10 rounded-full bg-amber-500/20 flex items-center justify-center text-safran mb-2 animate-bounce">
                          <Coffee className="w-5 h-5 text-safran fill-safran/20" />
                        </div>
                        <p className="text-2xl font-black text-safran font-display">
                          ~ {calculationResults.teaGlasses}
                        </p>
                        <p className="text-[10px] text-gray-400 font-medium uppercase mt-1">Thés offerts 🍵</p>
                      </div>

                    </motion.div>
                  )}

                  <p className="text-[10px] text-gray-400 text-center italic">
                    *Calcul basé sur la différence de carburant consommé par colis entre un fourgon de livraison conventionnel vide/semi-chargé et l'optimisation d'un espace vide existant dans les transports en commun.
                  </p>

                </div>

              </div>
            </div>

          </div>

        </div>
      </section>

      {/* SECTION DUO RECHERCHE / ANNONCES DE TRAJETS */}
      <section className="py-20 bg-white" id="marketplace">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto mb-12">
            <span className="text-xs font-bold uppercase tracking-widest text-sunset bg-sunset/10 px-4 py-1.5 rounded-full">
              Rechercher sur EcoDrop
            </span>
            <h2 className="text-3xl font-extrabold font-display text-charcoal mt-4 tracking-tight">
              Trajets & Demandes disponibles en ce moment
            </h2>
            <p className="text-gray-500 mt-2">
              Utilisez la recherche ci-dessous pour filtrer les départs par ville et prendre contact instantanément.
            </p>
          </div>

          {/* Formulaire de recherche et filtrage */}
          <div className="bg-gray-50 p-6 rounded-3xl border border-gray-100 max-w-4xl mx-auto mb-10 shadow-sm">
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-4 items-center">
              
              <div className="sm:col-span-4 relative">
                <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-sunset" />
                <input 
                  type="text" 
                  placeholder="Ville de départ (ex: Casablanca)" 
                  value={searchDepart}
                  onChange={(e) => setSearchDepart(e.target.value)}
                  className="w-full bg-white border border-gray-200 rounded-2xl pl-12 pr-4 py-3.5 text-sm focus:outline-none focus:border-sunset"
                />
              </div>

              <div className="sm:col-span-1 text-center font-bold text-gray-400 text-sm hidden sm:block">
                ➔
              </div>

              <div className="sm:col-span-4 relative">
                <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-menthe" />
                <input 
                  type="text" 
                  placeholder="Ville de destination (ex: Rabat)" 
                  value={searchArrivee}
                  onChange={(e) => setSearchArrivee(e.target.value)}
                  className="w-full bg-white border border-gray-200 rounded-2xl pl-12 pr-4 py-3.5 text-sm focus:outline-none focus:border-menthe"
                />
              </div>

              <div className="sm:col-span-3">
                <button 
                  onClick={() => { setSearchDepart(""); setSearchArrivee(""); }}
                  className="w-full bg-charcoal text-white hover:bg-charcoal/90 font-bold py-3.5 rounded-2xl text-xs tracking-wider uppercase transition-colors"
                >
                  Réinitialiser
                </button>
              </div>

            </div>
          </div>

          {/* Onglets de bascule Trajets (Droppers) VS Colis en attente */}
          <div className="flex justify-center gap-4 mb-8">
            <button
              onClick={() => setActiveTab("trajets")}
              className={`px-6 py-3 rounded-2xl font-bold text-sm transition-all flex items-center gap-2 ${activeTab === 'trajets' ? 'bg-sunset text-white shadow-md' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
            >
              <Train className="w-4 h-4" />
              Voyageurs Disponibles (Droppers) ({filteredTrajets.length})
            </button>
            <button
              onClick={() => setActiveTab("colis")}
              className={`px-6 py-3 rounded-2xl font-bold text-sm transition-all flex items-center gap-2 ${activeTab === 'colis' ? 'bg-menthe text-charcoal shadow-md' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
            >
              <Package className="w-4 h-4" />
              Colis en attente ({filteredColis.length})
            </button>
          </div>

          {/* Liste dynamique selon l'onglet actif */}
          <div className="max-w-5xl mx-auto">
            
            {activeTab === "trajets" ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6" id="trajets-list">
                {filteredTrajets.length > 0 ? (
                  filteredTrajets.map((t) => (
                    <div 
                      key={t.id}
                      className="bg-gray-50 rounded-3xl p-6 border border-gray-100 shadow-sm hover:shadow-xl transition-all duration-300 relative group flex flex-col justify-between"
                    >
                      <div>
                        {/* En-tête de la carte */}
                        <div className="flex justify-between items-start mb-4">
                          <div className="flex items-center gap-3">
                            <img 
                              src={t.avatar} 
                              alt={t.conducteur} 
                              className="w-12 h-12 rounded-full object-cover border-2 border-sunset"
                            />
                            <div>
                              <h4 className="font-bold text-charcoal flex items-center gap-1.5">
                                {t.conducteur}
                                <span className="inline-flex items-center text-xs text-safran bg-amber-500/10 px-1.5 py-0.5 rounded-lg">
                                  ★ {t.rating}
                                </span>
                              </h4>
                              <p className="text-xs text-gray-500 font-medium">{t.livraisonsCount} livraisons réussies</p>
                            </div>
                          </div>
                          
                          <span className="text-lg font-black text-sunset bg-orange-50 px-3 py-1.5 rounded-xl border border-sunset/10">
                            {t.tarif} DH
                          </span>
                        </div>

                        {/* Corps / Trajet */}
                        <div className="space-y-2 mb-4 bg-white p-4 rounded-2xl border border-gray-100 text-left">
                          <div className="flex items-center gap-2.5 text-sm">
                            <div className="w-2.5 h-2.5 rounded-full bg-sunset"></div>
                            <span className="font-semibold text-gray-800">Départ:</span>
                            <span className="text-gray-600">{t.departs}</span>
                          </div>
                          <div className="flex items-center gap-2.5 text-sm">
                            <div className="w-2.5 h-2.5 rounded-full bg-menthe"></div>
                            <span className="font-semibold text-gray-800">Arrivée:</span>
                            <span className="text-gray-600">{t.arrivee}</span>
                          </div>
                        </div>

                        {/* Métadonnées additionnelles */}
                        <div className="flex flex-wrap items-center gap-3 mb-6 text-xs text-gray-500">
                          <span className="flex items-center gap-1 bg-gray-100 px-2.5 py-1.5 rounded-xl font-medium">
                            <Clock className="w-3.5 h-3.5 text-sunset" /> {t.date}
                          </span>
                          <span className="flex items-center gap-1 bg-gray-100 px-2.5 py-1.5 rounded-xl font-medium">
                            {t.moyenTransport === 'train' ? <Train className="w-3.5 h-3.5 text-sunset" /> : t.moyenTransport === 'tram' ? <Bike className="w-3.5 h-3.5 text-menthe" /> : <Car className="w-3.5 h-3.5 text-safran" />}
                            Mode : <span className="capitalize text-gray-700 font-bold">{t.moyenTransport}</span>
                          </span>
                          <span className="bg-gray-100 px-2.5 py-1.5 rounded-xl font-semibold text-gray-600">
                            📦 {t.tailleColis}
                          </span>
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="pt-4 border-t border-gray-100/80 flex justify-between items-center">
                        <span className="text-xs font-semibold text-menthe bg-menthe/10 px-2.5 py-1 rounded-lg">
                          🟢 {t.statut}
                        </span>
                        
                        <button 
                          onClick={() => startChat(t)}
                          className="bg-charcoal text-white hover:bg-sunset hover:text-white font-bold text-xs px-4 py-2.5 rounded-xl transition-all flex items-center gap-1 cursor-pointer"
                        >
                          Discuter <MessageSquare className="w-3.5 h-3.5" />
                        </button>
                      </div>

                    </div>
                  ))
                ) : (
                  <div className="col-span-2 text-center py-12 bg-gray-50 rounded-3xl border border-dashed border-gray-200">
                    <Package className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                    <p className="text-gray-500 font-semibold">Aucun voyageur ne correspond à vos filtres.</p>
                    <button 
                      onClick={() => { setSearchDepart(""); setSearchArrivee(""); }}
                      className="text-sunset font-bold text-xs underline mt-2 hover:text-sunset/80"
                    >
                      Effacer la recherche
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6" id="colis-list">
                {filteredColis.length > 0 ? (
                  filteredColis.map((c) => (
                    <div 
                      key={c.id}
                      className="bg-gray-50 rounded-3xl p-6 border border-gray-100 shadow-sm hover:shadow-xl transition-all duration-300 relative group flex flex-col justify-between"
                    >
                      <div>
                        {/* En-tête colis */}
                        <div className="flex justify-between items-start mb-4">
                          <div>
                            <h4 className="font-extrabold text-charcoal text-lg font-display mb-1">{c.titre}</h4>
                            <p className="text-xs text-gray-500 font-medium">Posté par {c.expediteur}</p>
                          </div>
                          <span className="text-lg font-black text-menthe bg-emerald-50 px-3 py-1.5 rounded-xl border border-menthe/10">
                            {c.tarifPropose} DH
                          </span>
                        </div>

                        {/* Trajet du colis */}
                        <div className="space-y-2 mb-4 bg-white p-4 rounded-2xl border border-gray-100 text-left">
                          <div className="flex items-center gap-2.5 text-sm">
                            <div className="w-2.5 h-2.5 rounded-full bg-sunset"></div>
                            <span className="font-semibold text-gray-800">Départ:</span>
                            <span className="text-gray-600">{c.depart}</span>
                          </div>
                          <div className="flex items-center gap-2.5 text-sm">
                            <div className="w-2.5 h-2.5 rounded-full bg-menthe"></div>
                            <span className="font-semibold text-gray-800">Destination:</span>
                            <span className="text-gray-600">{c.arrivee}</span>
                          </div>
                        </div>

                        {/* Caractéristiques */}
                        <div className="flex flex-wrap items-center gap-3 mb-6 text-xs text-gray-500">
                          <span className="bg-gray-100 px-2.5 py-1.5 rounded-xl font-semibold text-gray-700">
                            📏 Taille : {c.taille}
                          </span>
                          <span className="bg-gray-100 px-2.5 py-1.5 rounded-xl font-medium flex items-center gap-1">
                            <Clock className="w-3.5 h-3.5 text-sunset" /> {c.date}
                          </span>
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="pt-4 border-t border-gray-100/80 flex items-center justify-between">
                        <span className="text-xs font-semibold text-sunset bg-orange-50 px-2.5 py-1 rounded-lg">
                          ⚠️ Livraison demandée
                        </span>
                        
                        <button 
                          onClick={() => {
                            showToast(`💚 Demande de transport acceptée ! Vous allez être mis en relation avec ${c.expediteur}.`);
                          }}
                          className="bg-menthe text-charcoal hover:bg-menthe/95 font-bold text-xs px-4 py-2.5 rounded-xl transition-all flex items-center gap-1 cursor-pointer"
                        >
                          Proposer de le prendre <ChevronRight className="w-3.5 h-3.5" />
                        </button>
                      </div>

                    </div>
                  ))
                ) : (
                  <div className="col-span-2 text-center py-12 bg-gray-50 rounded-3xl border border-dashed border-gray-200">
                    <Package className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                    <p className="text-gray-500 font-semibold">Aucun colis en attente de transport pour ces villes.</p>
                    <button 
                      onClick={() => { setSearchDepart(""); setSearchArrivee(""); }}
                      className="text-sunset font-bold text-xs underline mt-2 hover:text-sunset/80"
                    >
                      Effacer la recherche
                    </button>
                  </div>
                )}
              </div>
            )}

          </div>

        </div>
      </section>

      {/* SECTION SÉCURITÉ & TRANSPARENCE */}
      <section className="py-20 bg-gray-50 border-t border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            
            {/* Colonne gauche : Texte */}
            <div className="text-left space-y-6">
              <span className="text-xs font-bold uppercase tracking-widest text-sunset bg-sunset/10 px-4 py-1.5 rounded-full">
                La sécurité avant tout
              </span>
              <h2 className="text-3xl sm:text-4xl font-extrabold font-display text-charcoal leading-tight">
                Expédiez et voyagez l'esprit tranquille
              </h2>
              <p className="text-gray-500 leading-relaxed">
                Chez EcoDrop Maroc, la confiance est le ciment de notre communauté. Nous avons développé plusieurs garde-fous pour garantir le bon acheminement de chaque objet et la sérénité de chaque Dropper.
              </p>

              <div className="space-y-4 pt-2">
                
                {/* Sécurité 1 */}
                <div className="flex gap-4">
                  <div className="w-10 h-10 rounded-xl bg-orange-100 flex items-center justify-center text-sunset shrink-0">
                    <Shield className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-charcoal text-base">Profils vérifiés à 100%</h4>
                    <p className="text-xs text-gray-500 mt-1">
                      Carte d'identité nationale (CNI), numéro de téléphone et adresse e-mail vérifiés avant la première publication.
                    </p>
                  </div>
                </div>

                {/* Sécurité 2 */}
                <div className="flex gap-4">
                  <div className="w-10 h-10 rounded-xl bg-emerald-100 flex items-center justify-center text-menthe shrink-0">
                    <Check className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-charcoal text-base">Code de vérification sécurisé</h4>
                    <p className="text-xs text-gray-500 mt-1">
                      Un code unique est envoyé à l'expéditeur et au destinataire. Le Dropper ne valide la livraison (et ne reçoit sa gratification) qu'une fois ce code saisi.
                    </p>
                  </div>
                </div>

                {/* Sécurité 3 */}
                <div className="flex gap-4">
                  <div className="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center text-safran shrink-0">
                    <Star className="w-5 h-5 fill-safran/20" />
                  </div>
                  <div>
                    <h4 className="font-bold text-charcoal text-base">Évaluation bilatérale transparente</h4>
                    <p className="text-xs text-gray-500 mt-1">
                      Expéditeurs et Droppers s'évaluent après chaque transaction, garantissant une communauté saine et respectueuse.
                    </p>
                  </div>
                </div>

              </div>
            </div>

            {/* Colonne droite : Illustration stylisée */}
            <div className="relative flex justify-center lg:justify-end">
              <div className="bg-gradient-to-tr from-sunset to-safran p-8 rounded-[40px] shadow-xl w-full max-w-[450px] text-white text-left relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-2xl"></div>
                
                <h4 className="text-lg font-extrabold mb-4 flex items-center gap-2">
                  🛡️ Garantie Solidaire EcoDrop
                </h4>
                <p className="text-xs text-white/90 leading-relaxed mb-6">
                  Tous les objets transportés via la plateforme font l'objet d'un engagement moral et d'une charte de bon voisinage. En cas de retard important, notre service d'assistance marocain basé à Casablanca intervient sous 15 minutes.
                </p>

                <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/10 flex items-center gap-3">
                  <div className="bg-white rounded-full p-2 text-sunset">
                    <Award className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs font-bold">Assistance locale 24h/24</p>
                    <p className="text-[10px] text-white/80">Dispo par WhatsApp au Maroc</p>
                  </div>
                </div>

                <div className="mt-6 flex justify-between items-center text-[11px] text-white/80 border-t border-white/10 pt-4">
                  <span>Rejoignez la charte</span>
                  <span className="font-bold underline cursor-pointer hover:text-white">Lire la charte verte ➔</span>
                </div>
              </div>
            </div>

          </div>

        </div>
      </section>

      {/* SECTION FOIRE AUX QUESTIONS (FAQ) */}
      <section className="py-20 bg-white" id="faq">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-xs font-bold uppercase tracking-widest text-menthe bg-menthe/10 px-4 py-1.5 rounded-full">
              Des questions ?
            </span>
            <h2 className="text-3xl font-extrabold font-display text-charcoal mt-4 tracking-tight">
              Foire Aux Questions
            </h2>
            <p className="text-gray-500 mt-2">
              Tout ce que vous devez savoir pour démarrer sereinement sur la plateforme.
            </p>
          </div>

          <div className="space-y-4" id="faq-accordions">
            
            {/* FAQ 1 */}
            <FAQItem 
              question="Est-ce légal et sécurisé ?"
              answer="Oui ! Le transport collaboratif de colis entre particuliers est parfaitement légal tant qu'il s'agit d'une participation aux frais de transport (gratification) et non d'une activité commerciale à plein temps sans déclaration. C'est l'application du principe de l'économie de partage. Pour la sécurité, tous les Droppers sont identifiés à l'aide de leur CNI."
            />

            {/* FAQ 2 */}
            <FAQItem 
              question="Quel type de colis puis-je faire livrer ?"
              answer="Vous pouvez envoyer tout objet légal de petite ou moyenne taille : clés oubliées, documents urgents, ordinateurs portables, vêtements, livres, gâteaux marocains faits maison... Sont strictement interdits : tous les produits illégaux, dangereux, inflammables ou nécessitant une réfrigération contrôlée."
            />

            {/* FAQ 3 */}
            <FAQItem 
              question="Comment est fixé le tarif du trajet ?"
              answer="Les tarifs sont totalement libres mais EcoDrop suggère une grille équitable basée sur la distance. Par exemple : 15 DH pour un trajet en ville, 40 DH pour un Casa-Rabat, et environ 60 à 80 DH pour des trajets plus longs de type Marrakech-Tanger. Cela sert simplement de dédommagement au voyageur pour son temps et son détour."
            />

            {/* FAQ 4 */}
            <FAQItem 
              question="Où se passe la remise et la réception du colis ?"
              answer="Le point de rendez-vous est convenu d'un commun accord via le chat sécurisé de l'application. Généralement, les gares ferroviaires ONCF (Casa Voyageurs, Rabat Agdal, Marrakech Oasis, Tanger Ville) sont les endroits les plus pratiques car les Droppers s'y trouvent déjà dans le cadre de leur voyage !"
            />

            {/* FAQ 5 */}
            <FAQItem 
              question="Que se passe-t-il si le colis est perdu ou endommagé ?"
              answer="Chaque voyageur s'engage moralement à prendre un soin infini de vos affaires (comme s'il s'agissait des siennes). En cas de problème de force majeure, la communauté applique une politique d'indemnisation mutuelle solidaire et notre support marocain est joignable 7j/7 pour arbitrer et aider."
            />

          </div>

        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-charcoal text-gray-400 py-16 border-t border-gray-800" id="main-footer">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
            
            {/* Col 1 : Marque */}
            <div className="space-y-4 text-left">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center">
                  <svg viewBox="0 0 100 100" className="w-7 h-7" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M20 35 L50 20 L80 35 L50 50 Z" stroke="#FF5722" strokeWidth="6" strokeLinejoin="round" fill="#FF5722" fillOpacity="0.1"/>
                    <path d="M20 35 L20 65 L50 80 L50 50 Z" stroke="#FF5722" strokeWidth="6" strokeLinejoin="round" />
                    <path d="M80 35 L80 65 L50 80 L50 50 Z" stroke="#FF5722" strokeWidth="6" strokeLinejoin="round" />
                    <path d="M50 15 C30 35 30 55 50 75 C70 55 70 35 50 15 Z" fill="#00E676" fillOpacity="0.8" stroke="#FFFFFF" strokeWidth="3" />
                  </svg>
                </div>
                <span className="text-lg font-extrabold font-display text-white">
                  EcoDrop <span className="text-sunset">Maroc</span>
                </span>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed">
                La première plateforme marocaine de livraison collaborative de colis entre particuliers. Faisons voyager nos colis de manière responsable, économique et conviviale.
              </p>
              <div className="text-xs text-gray-500 font-semibold">
                🇲🇦 Conçu à Casablanca, au service de tout le Maroc.
              </div>
            </div>

            {/* Col 2 : Liens rapides */}
            <div className="text-left space-y-4">
              <h4 className="text-sm font-bold text-white uppercase tracking-wider">Le Concept</h4>
              <ul className="space-y-2 text-xs">
                <li><a href="#concept" className="hover:text-white transition-colors">Comment ça marche</a></li>
                <li><a href="#advantages" className="hover:text-white transition-colors">Notre charte d'engagement</a></li>
                <li><a href="#simulator" className="hover:text-white transition-colors">Simulateur de CO2</a></li>
                <li><a href="#marketplace" className="hover:text-white transition-colors">Rechercher un voyageur</a></li>
              </ul>
            </div>

            {/* Col 3 : Villes desservies */}
            <div className="text-left space-y-4">
              <h4 className="text-sm font-bold text-white uppercase tracking-wider">Axes populaires</h4>
              <ul className="space-y-2 text-xs text-gray-500">
                <li><span className="text-gray-400">Casablanca ➔ Rabat</span> (ONCF Navette)</li>
                <li><span className="text-gray-400">Casablanca ➔ Marrakech</span> (ONCF / Voiture)</li>
                <li><span className="text-gray-400">Rabat ➔ Tanger</span> (Al Boraq Grande Vitesse)</li>
                <li><span className="text-gray-400">Marrakech ➔ Agadir</span> (Autoroute)</li>
              </ul>
            </div>

            {/* Col 4 : Newsletter / Contact */}
            <div className="text-left space-y-4">
              <h4 className="text-sm font-bold text-white uppercase tracking-wider">Rejoindre la communauté</h4>
              <p className="text-xs text-gray-500">
                Inscrivez-vous à notre lettre d'information pour recevoir des codes promo et des récits d'impact écologiques marocains.
              </p>
              <div className="flex">
                <input 
                  type="email" 
                  placeholder="votre.email@domain.ma" 
                  className="bg-white/5 border border-white/10 rounded-l-xl px-3 py-2 text-xs w-full focus:outline-none focus:border-sunset text-white"
                />
                <button 
                  onClick={() => showToast("💚 Merci de vous être inscrit à la newsletter EcoDrop !")}
                  className="bg-sunset hover:bg-sunset/90 text-white px-3 py-2 rounded-r-xl transition-colors"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

          </div>

          {/* Copyright */}
          <div className="pt-8 border-t border-gray-800 text-center text-xs text-gray-600 flex flex-col sm:flex-row justify-between items-center gap-4">
            <p>© 2026 EcoDrop Maroc. Tous droits réservés.</p>
            <div className="flex gap-6">
              <a href="#" className="hover:text-white transition-colors">Mentions Légales</a>
              <a href="#" className="hover:text-white transition-colors">Politique de Confidentialité</a>
              <a href="#" className="hover:text-white transition-colors">Contact Support</a>
            </div>
          </div>

        </div>
      </footer>


      {/* MODAL : DEVENIR DROPPER (Proposer un Trajet) */}
      <AnimatePresence>
        {isDropperModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Overlay flouté */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsDropperModalOpen(false)}
              className="absolute inset-0 bg-charcoal/70 backdrop-blur-sm"
            ></motion.div>

            {/* Contenu modal */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white rounded-[32px] w-full max-w-lg p-8 shadow-2xl relative z-10 max-h-[90vh] overflow-y-auto border border-gray-100"
              id="dropper-modal"
            >
              <button 
                onClick={() => setIsDropperModalOpen(false)}
                className="absolute top-6 right-6 text-gray-400 hover:text-charcoal p-1.5 rounded-full bg-gray-100 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="text-left mb-6">
                <span className="text-xs font-bold text-sunset bg-orange-50 px-3 py-1 rounded-full uppercase tracking-wider">
                  Publier un voyage 🇲🇦
                </span>
                <h3 className="text-2xl font-extrabold font-display text-charcoal mt-2">
                  Devenez Dropper EcoDrop
                </h3>
                <p className="text-sm text-gray-500 mt-1">
                  Proposez d'emporter un colis lors de votre prochain trajet et aidez un voisin tout en remboursant vos frais de voyage.
                </p>
              </div>

              <form onSubmit={handleAddTrajet} className="space-y-4 text-left">
                
                {/* Départ & Arrivée */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-gray-700">Ville de départ :</label>
                    <input 
                      type="text" 
                      required
                      placeholder="Ex: Casablanca"
                      value={newTrajet.departs}
                      onChange={(e) => setNewTrajet({...newTrajet, departs: e.target.value})}
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-sunset focus:bg-white transition-colors"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-gray-700">Ville d'arrivée :</label>
                    <input 
                      type="text" 
                      required
                      placeholder="Ex: Marrakech"
                      value={newTrajet.arrivee}
                      onChange={(e) => setNewTrajet({...newTrajet, arrivee: e.target.value})}
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-sunset focus:bg-white transition-colors"
                    />
                  </div>
                </div>

                {/* Date / Fréquence */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-gray-700">Date et heure de départ :</label>
                  <input 
                    type="text" 
                    placeholder="Ex: Aujourd'hui à 16h, ou Demain matin"
                    value={newTrajet.date}
                    onChange={(e) => setNewTrajet({...newTrajet, date: e.target.value})}
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-sunset focus:bg-white transition-colors"
                  />
                </div>

                {/* Moyen de transport */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-gray-700">Votre moyen de transport :</label>
                  <select 
                    value={newTrajet.moyenTransport}
                    onChange={(e) => setNewTrajet({...newTrajet, moyenTransport: e.target.value as "train" | "tram" | "voiture"})}
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-sunset focus:bg-white transition-colors"
                  >
                    <option value="train">Train ONCF (Recommandé - Écologique)</option>
                    <option value="voiture">Voiture Partagée / Personnel</option>
                    <option value="tram">Tramway / Vélo (Urbain de proximité)</option>
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  {/* Taille colis max accepté */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-gray-700">Taille de colis acceptée :</label>
                    <select 
                      value={newTrajet.tailleColis}
                      onChange={(e) => setNewTrajet({...newTrajet, tailleColis: e.target.value})}
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-3 text-sm focus:outline-none focus:border-sunset focus:bg-white transition-colors"
                    >
                      <option value="Petit (clés, ordi, plis)">Petit (Plis, clés, papiers)</option>
                      <option value="Moyen (boîte à chaussures)">Moyen (Boîte, petit carton)</option>
                      <option value="Grand (valise ou carton)">Grand (Valise, gros sac)</option>
                    </select>
                  </div>

                  {/* Tarif suggéré */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-gray-700">Tarif demandé (DH) :</label>
                    <div className="relative">
                      <input 
                        type="number" 
                        required
                        min="10"
                        value={newTrajet.tarif}
                        onChange={(e) => setNewTrajet({...newTrajet, tarif: Number(e.target.value)})}
                        className="w-full bg-gray-50 border border-gray-200 rounded-xl pl-4 pr-12 py-3 text-sm focus:outline-none focus:border-sunset focus:bg-white transition-colors"
                      />
                      <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-bold text-gray-500">DH</span>
                    </div>
                  </div>
                </div>

                {/* Statut / Détails additionnels */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-gray-700">Commentaires pour rassurer les expéditeurs :</label>
                  <input 
                    type="text" 
                    placeholder="Ex: Je prends l'Al Boraq, je peux attendre devant la gare d'arrivée."
                    value={newTrajet.statut}
                    onChange={(e) => setNewTrajet({...newTrajet, statut: e.target.value})}
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-sunset focus:bg-white transition-colors"
                  />
                </div>

                {/* Consentement charte */}
                <div className="flex items-start gap-2.5 pt-2">
                  <input type="checkbox" required id="agree-charter" className="mt-1 accent-sunset" />
                  <label htmlFor="agree-charter" className="text-[11px] text-gray-500 leading-normal">
                    Je certifie sur l'honneur que je n'emporte aucun produit illégal, dangereux ou contrefait et que je respecterai les horaires convenus.
                  </label>
                </div>

                {/* Validation */}
                <button 
                  type="submit"
                  className="w-full bg-sunset text-white hover:bg-sunset/90 font-bold py-4 rounded-xl mt-4 shadow-lg shadow-sunset/15 text-sm transition-transform hover:scale-[1.01] active:scale-[1] cursor-pointer"
                >
                  🚀 Publier mon Trajet & Rejoindre les Droppers
                </button>

              </form>

            </motion.div>
          </div>
        )}
      </AnimatePresence>


      {/* MODAL : EXPÉDIER UN COLIS */}
      <AnimatePresence>
        {isExpedierModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Overlay flouté */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsExpedierModalOpen(false)}
              className="absolute inset-0 bg-charcoal/70 backdrop-blur-sm"
            ></motion.div>

            {/* Contenu modal */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white rounded-[32px] w-full max-w-lg p-8 shadow-2xl relative z-10 max-h-[90vh] overflow-y-auto border border-gray-100"
              id="expedier-modal"
            >
              <button 
                onClick={() => setIsExpedierModalOpen(false)}
                className="absolute top-6 right-6 text-gray-400 hover:text-charcoal p-1.5 rounded-full bg-gray-100 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="text-left mb-6">
                <span className="text-xs font-bold text-menthe bg-emerald-50 px-3 py-1 rounded-full uppercase tracking-wider">
                  Besoin d'expédition 📦
                </span>
                <h3 className="text-2xl font-extrabold font-display text-charcoal mt-2">
                  Demander une Livraison
                </h3>
                <p className="text-sm text-gray-500 mt-1">
                  Indiquez ce que vous souhaitez envoyer, les voyageurs à proximité vont vous contacter pour effectuer la livraison.
                </p>
              </div>

              <form onSubmit={handleAddColis} className="space-y-4 text-left">
                
                {/* Intitulé du colis */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-gray-700">Que souhaitez-vous envoyer ? (Objet) :</label>
                  <input 
                    type="text" 
                    required
                    placeholder="Ex: Clés d'appartement de secours, Boîtier lunettes..."
                    value={newColis.titre}
                    onChange={(e) => setNewColis({...newColis, titre: e.target.value})}
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-menthe focus:bg-white transition-colors"
                  />
                </div>

                {/* Villes de transport */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-gray-700">Ville de départ :</label>
                    <input 
                      type="text" 
                      required
                      placeholder="Ex: Casablanca"
                      value={newColis.depart}
                      onChange={(e) => setNewColis({...newColis, depart: e.target.value})}
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-menthe focus:bg-white transition-colors"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-gray-700">Ville de destination :</label>
                    <input 
                      type="text" 
                      required
                      placeholder="Ex: Rabat"
                      value={newColis.arrivee}
                      onChange={(e) => setNewColis({...newColis, arrivee: e.target.value})}
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-menthe focus:bg-white transition-colors"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  {/* Taille du colis */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-gray-700">Taille approximative :</label>
                    <select 
                      value={newColis.taille}
                      onChange={(e) => setNewColis({...newColis, taille: e.target.value as "Enveloppe" | "Moyen" | "Grand"})}
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-3 text-sm focus:outline-none focus:border-menthe focus:bg-white transition-colors"
                    >
                      <option value="Enveloppe">Enveloppe / Très Petit</option>
                      <option value="Moyen">Moyen (Boîte à chaussures)</option>
                      <option value="Grand">Grand (Valise, gros sac)</option>
                    </select>
                  </div>

                  {/* Gratification proposée */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-gray-700">Récompense proposée (DH) :</label>
                    <div className="relative">
                      <input 
                        type="number" 
                        required
                        min="10"
                        value={newColis.tarifPropose}
                        onChange={(e) => setNewColis({...newColis, tarifPropose: Number(e.target.value)})}
                        className="w-full bg-gray-50 border border-gray-200 rounded-xl pl-4 pr-12 py-3 text-sm focus:outline-none focus:border-menthe focus:bg-white transition-colors"
                      />
                      <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-bold text-gray-500">DH</span>
                    </div>
                  </div>
                </div>

                {/* Urgence / Délai */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-gray-700">Quand la livraison doit-elle avoir lieu ?</label>
                  <input 
                    type="text" 
                    placeholder="Ex: Avant ce soir 18h, ce week-end..."
                    value={newColis.date}
                    onChange={(e) => setNewColis({...newColis, date: e.target.value})}
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-menthe focus:bg-white transition-colors"
                  />
                </div>

                {/* Consentement de contrôle */}
                <div className="flex items-start gap-2.5 pt-2">
                  <input type="checkbox" required id="agree-inspection" className="mt-1 accent-menthe" />
                  <label htmlFor="agree-inspection" className="text-[11px] text-gray-500 leading-normal">
                    J'accepte que le Dropper puisse inspecter visuellement le contenu du paquet lors de la prise en charge pour s'assurer de sa conformité avec la loi marocaine.
                  </label>
                </div>

                {/* Validation */}
                <button 
                  type="submit"
                  className="w-full bg-menthe text-charcoal hover:bg-menthe/95 font-bold py-4 rounded-xl mt-4 shadow-lg shadow-menthe/15 text-sm transition-transform hover:scale-[1.01] active:scale-[1] cursor-pointer"
                >
                  📦 Publier ma Demande de Livraison
                </button>

              </form>

            </motion.div>
          </div>
        )}
      </AnimatePresence>


      {/* MODAL : LIVE CHAT SIMULATEUR */}
      <AnimatePresence>
        {isChatModalOpen && selectedDriver && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            
            {/* Overlay flouté */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsChatModalOpen(false)}
              className="absolute inset-0 bg-charcoal/70 backdrop-blur-sm"
            ></motion.div>

            {/* Contenu modal */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white rounded-[32px] w-full max-w-md h-[550px] shadow-2xl relative z-10 flex flex-col justify-between overflow-hidden border border-gray-100"
              id="chat-modal"
            >
              {/* En-tête du chat */}
              <div className="bg-charcoal text-white p-5 flex justify-between items-center shrink-0">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <img 
                      src={selectedDriver.avatar} 
                      alt={selectedDriver.conducteur} 
                      className="w-10 h-10 rounded-full object-cover border-2 border-sunset"
                    />
                    <span className="absolute bottom-0 right-0 w-3 h-3 bg-menthe rounded-full border-2 border-charcoal"></span>
                  </div>
                  <div className="text-left">
                    <p className="font-bold text-sm leading-none flex items-center gap-1">
                      {selectedDriver.conducteur}
                    </p>
                    <p className="text-[10px] text-gray-400 mt-1 flex items-center gap-1">
                      <span>🟢 En ligne</span>
                      <span>•</span>
                      <span className="text-safran">★ {selectedDriver.rating}</span>
                    </p>
                  </div>
                </div>
                
                <button 
                  onClick={() => setIsChatModalOpen(false)}
                  className="text-gray-400 hover:text-white p-1.5 rounded-full bg-white/5 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Zone de messages */}
              <div className="flex-1 bg-gray-50 p-5 overflow-y-auto space-y-4">
                {chatMessages.map((msg, idx) => (
                  <div 
                    key={idx}
                    className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div 
                      className={`max-w-[80%] rounded-2xl p-4 text-xs leading-relaxed ${msg.sender === 'user' ? 'bg-sunset text-white rounded-br-none text-left' : 'bg-white text-charcoal border border-gray-100 rounded-bl-none text-left shadow-sm'}`}
                    >
                      <p>{msg.text}</p>
                      <span className={`block text-[8px] text-right mt-1 ${msg.sender === 'user' ? 'text-white/70' : 'text-gray-400'}`}>
                        {msg.time}
                      </span>
                    </div>
                  </div>
                ))}

                {/* Indicateur de saisie */}
                {isDriverTyping && (
                  <div className="flex justify-start">
                    <div className="bg-white border border-gray-100 rounded-2xl rounded-bl-none p-3.5 flex items-center gap-1 shadow-sm">
                      <div className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce"></div>
                      <div className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce [animation-delay:0.2s]"></div>
                      <div className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce [animation-delay:0.4s]"></div>
                    </div>
                  </div>
                )}
              </div>

              {/* Pied du chat (Formulaire de saisie) */}
              <form onSubmit={sendChatMessage} className="p-4 bg-white border-t border-gray-100 flex gap-2 shrink-0">
                <input 
                  type="text" 
                  placeholder="Écrivez un message chaleureux..."
                  value={currentChatMessage}
                  onChange={(e) => setCurrentChatMessage(e.target.value)}
                  className="flex-1 bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-xs focus:outline-none focus:border-sunset text-charcoal"
                />
                <button 
                  type="submit"
                  className="bg-sunset text-white hover:bg-sunset/90 p-3 rounded-xl transition-colors shrink-0 flex items-center justify-center cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}

// Composant FAQ rétractable (Accordion)
function FAQItem({ question, answer }: { question: string; answer: string }) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="bg-gray-50 rounded-2xl border border-gray-100 overflow-hidden transition-all duration-300">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full px-6 py-5 flex justify-between items-center text-left font-bold text-sm sm:text-base text-charcoal hover:bg-gray-100/50 transition-colors focus:outline-none"
      >
        <span>{question}</span>
        <ChevronDown className={`w-5 h-5 text-gray-500 transition-transform duration-300 shrink-0 ${isOpen ? 'rotate-180 text-sunset' : ''}`} />
      </button>

      <AnimatePresence initial={false}>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="px-6 pb-5 pt-1 text-xs sm:text-sm text-gray-500 leading-relaxed border-t border-gray-100/30 text-left bg-white/40">
              {answer}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
